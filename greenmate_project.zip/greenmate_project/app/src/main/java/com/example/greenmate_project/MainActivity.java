package com.example.greenmate_project;

import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {
    private FragmentManager fragmentManager = getSupportFragmentManager();
    private ScanActivity scanActivity = new ScanActivity();
    private ListActivity listActivity = new ListActivity();
    private SearchActivity searchActivity = new SearchActivity();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.content_layout, scanActivity).commitAllowingStateLoss();

        BottomNavigationView bottomNavigationView = findViewById(R.id.nav_view);
        bottomNavigationView.setOnNavigationItemSelectedListener(new ItemSelectedListener());
    }

    class ItemSelectedListener implements BottomNavigationView.OnNavigationItemSelectedListener{
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            FragmentTransaction transaction = fragmentManager.beginTransaction();

            switch(menuItem.getItemId())
            {
                case R.id.scan_item:
                    getSupportFragmentManager().beginTransaction() .replace(R.id.content_layout, scanActivity).commitAllowingStateLoss();
                    return true;

                case R.id.list_item:
                    getSupportFragmentManager().beginTransaction() .replace(R.id.content_layout, listActivity).commitAllowingStateLoss();
                    return true;
                case R.id.search_item:
                    getSupportFragmentManager().beginTransaction() .replace(R.id.content_layout, searchActivity).commitAllowingStateLoss();
                    return true;
            }
            return true;
        }
    }
}